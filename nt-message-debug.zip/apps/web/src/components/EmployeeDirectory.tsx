import {
  useEffect,
  useState,
} from "react";

import type {
  FormEvent,
} from "react";

import { ProtectedAvatar } from "./ProtectedAvatar";
import {
  listDirectoryEmployees,
} from "../services/directory.service";

import type {
  AccountRole,
} from "../types/auth";

import type {
  DirectoryAccountStatus,
  DirectoryActivationStatus,
  DirectoryEmployee,
  DirectoryEmployeeStatus,
  DirectoryEmploymentStatus,
  DirectoryListResponse,
  DirectoryRecordStatus,
} from "../types/directory";

interface EmployeeDirectoryProps {
  accessToken: string;
  reloadKey?: number;
  title?: string;
  description?: string;
  onSelectEmployee?: (
    employeeId: string,
  ) => void;
  selectedEmployeeId?: string | null;
}

type RoleFilter =
  | AccountRole
  | "";

type EmployeeStatusFilter =
  | DirectoryEmployeeStatus
  | "";

type EmploymentStatusFilter =
  | DirectoryEmploymentStatus
  | "";

type AccountStatusFilter =
  | DirectoryAccountStatus
  | "";

type ActivationStatusFilter =
  | DirectoryActivationStatus
  | "";

const PAGE_SIZE = 20;

function getErrorMessage(
  error: unknown,
): string {
  return error instanceof Error
    ? error.message
    : "The employee directory could not be loaded.";
}

function formatValue(
  value: string,
): string {
  return value
    .toLowerCase()
    .split("_")
    .map(
      (part) =>
        part.charAt(0).toUpperCase() +
        part.slice(1),
    )
    .join(" ");
}

function formatDate(
  value: string | null,
): string {
  if (!value) {
    return "Never";
  }

  const date =
    new Date(value);

  if (
    Number.isNaN(
      date.getTime(),
    )
  ) {
    return "Not available";
  }

  return new Intl.DateTimeFormat(
    "en-GB",
    {
      dateStyle: "medium",
      timeStyle: "short",
    },
  ).format(date);
}

function getStatusClass(
  value: string,
): string {
  return value
    .toLowerCase()
    .replaceAll(
      "_",
      "-",
    );
}

function getCurrentPositionLabel(
  employee: DirectoryEmployee,
): string {
  const position =
    employee.currentPosition;

  if (!position) {
    return "No management position";
  }

  if (
    position.positionType ===
    "SENIOR_MANAGEMENT"
  ) {
    return `${position.division.name} Senior Management`;
  }

  return `${position.department?.name ?? "Department"} Team Manager`;
}

export function EmployeeDirectory({
  accessToken,
  reloadKey = 0,
  title = "Employee Directory",
  description =
    "Search authorized Nepal Telecom employees within your permitted organization scope.",
  onSelectEmployee,
  selectedEmployeeId = null,
}: EmployeeDirectoryProps) {
  const [
    response,
    setResponse,
  ] =
    useState<DirectoryListResponse | null>(
      null,
    );

  const [
    searchInput,
    setSearchInput,
  ] =
    useState("");

  const [
    search,
    setSearch,
  ] =
    useState("");

  const [
    role,
    setRole,
  ] =
    useState<RoleFilter>("");

  const [
    employeeStatus,
    setEmployeeStatus,
  ] =
    useState<EmployeeStatusFilter>("");

  const [
    employmentStatus,
    setEmploymentStatus,
  ] =
    useState<EmploymentStatusFilter>("");

  const [
    recordStatus,
    setRecordStatus,
  ] =
    useState<DirectoryRecordStatus>(
      "CURRENT",
    );

  const [
    accountStatus,
    setAccountStatus,
  ] =
    useState<AccountStatusFilter>("");

  const [
    activationStatus,
    setActivationStatus,
  ] =
    useState<ActivationStatusFilter>("");

  const [page, setPage] =
    useState(1);

  const [
    loading,
    setLoading,
  ] =
    useState(true);

  const [error, setError] =
    useState("");

  const [
    refreshKey,
    setRefreshKey,
  ] =
    useState(0);

  useEffect(() => {
    let active = true;

    // Scope rules are enforced by the backend.
    listDirectoryEmployees(
      accessToken,
      {
        search:
          search || undefined,

        role:
          role || undefined,

        status:
          employeeStatus ||
          undefined,

        employmentStatus:
          employmentStatus ||
          undefined,

        recordStatus,

        accountStatus:
          accountStatus ||
          undefined,

        activationStatus:
          activationStatus ||
          undefined,

        page,
        limit: PAGE_SIZE,
      },
    )
      .then(
        (
          directoryResponse,
        ) => {
          if (!active) {
            return;
          }

          setResponse(
            directoryResponse,
          );

          setError("");
        },
      )
      .catch(
        (
          requestError:
            unknown,
        ) => {
          if (!active) {
            return;
          }

          setError(
            getErrorMessage(
              requestError,
            ),
          );
        },
      )
      .finally(() => {
        if (active) {
          setLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [
    accessToken,
    accountStatus,
    activationStatus,
    employeeStatus,
    employmentStatus,
    page,
    refreshKey,
    reloadKey,
    recordStatus,
    role,
    search,
  ]);

  function renderDirectoryAvatar(employee: DirectoryEmployee) {
    return (
      <ProtectedAvatar
        employeeId={employee.id}
        photoKey={employee.profilePhotoKey}
        displayName={employee.empName}
        className="directory-avatar"
        ariaLabel={`${employee.empName} profile`}
      />
    );
  }

  function submitSearch(
    event:
      FormEvent<HTMLFormElement>,
  ): void {
    event.preventDefault();

    setPage(1);
    setLoading(true);
    setError("");

    setSearch(
      searchInput.trim(),
    );
  }

  function clearFilters():
    void {
    setSearchInput("");
    setSearch("");
    setRole("");
    setEmployeeStatus("");
    setEmploymentStatus("");
    setAccountStatus("");
    setActivationStatus("");
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeRecordStatus(
    value:
      DirectoryRecordStatus,
  ): void {
    setRecordStatus(value);

    // Show all records when changing directory sections.
    setSearchInput("");
    setSearch("");
    setRole("");
    setEmployeeStatus("");
    setEmploymentStatus("");
    setAccountStatus("");
    setActivationStatus("");
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeRole(
    value: RoleFilter,
  ): void {
    setRole(value);
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeEmployeeStatus(
    value:
      EmployeeStatusFilter,
  ): void {
    setEmployeeStatus(value);
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeEmploymentStatus(
    value:
      EmploymentStatusFilter,
  ): void {
    setEmploymentStatus(value);
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeAccountStatus(
    value:
      AccountStatusFilter,
  ): void {
    setAccountStatus(value);
    setPage(1);
    setLoading(true);
    setError("");
  }

  function changeActivationStatus(
    value:
      ActivationStatusFilter,
  ): void {
    setActivationStatus(value);
    setPage(1);
    setLoading(true);
    setError("");
  }

  function retryLoading():
    void {
    setLoading(true);
    setError("");

    setRefreshKey(
      (current) =>
        current + 1,
    );
  }

  function changePage(
    nextPage: number,
  ): void {
    const totalPages =
      response?.pagination
        .totalPages ?? 0;

    if (
      nextPage < 1 ||
      (
        totalPages > 0 &&
        nextPage > totalPages
      ) ||
      nextPage === page
    ) {
      return;
    }

    setPage(nextPage);
    setLoading(true);
    setError("");
  }

  function selectEmployee(
    employee:
      DirectoryEmployee,
  ): void {
    onSelectEmployee?.(
      employee.id,
    );
  }

  const scope =
    response?.scope;

  const employees =
    response?.data ?? [];

  const pagination =
    response?.pagination;

  const firstVisibleRecord =
    pagination &&
    pagination.total > 0
      ? (pagination.page - 1) *
          PAGE_SIZE +
        1
      : 0;

  const lastVisibleRecord =
    pagination
      ? Math.min(
          pagination.page *
            PAGE_SIZE,
          pagination.total,
        )
      : 0;

  const hasActiveFilters =
    Boolean(
      search ||
      role ||
      employeeStatus ||
      employmentStatus ||
      accountStatus ||
      activationStatus,
    );

  return (
    <section
      className="directory-card"
      aria-busy={
        loading
      }
    >
      <header className="directory-header">
        <div className="directory-header__copy">
          <span>
            Organization directory
          </span>

          <h2>
            {recordStatus ===
            "ARCHIVED"
              ? "Archived Employee Records"
              : title}
          </h2>

          <p>
            {recordStatus ===
            "ARCHIVED"
              ? "Review archived Nepal Telecom employees and their preserved lifecycle records."
              : description}
          </p>
        </div>

        <div className="directory-total">
          <span
            className="directory-total__icon"
            aria-hidden="true"
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
            >
              <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
              <circle cx="9" cy="7" r="4" />
              <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
            </svg>
          </span>

          <span>
            {recordStatus ===
            "ARCHIVED"
              ? "Archived records"
              : "Current records"}
          </span>

          <strong>
            {pagination?.total ??
              0}
          </strong>
        </div>
      </header>

      {scope?.role ===
        "SUPER_ADMIN" && (
        <nav
          className="directory-record-tabs"
          aria-label="Employee record sections"
        >
          <button
            type="button"
            className={
              recordStatus ===
              "CURRENT"
                ? "active"
                : ""
            }
            onClick={() =>
              changeRecordStatus(
                "CURRENT",
              )
            }
          >
            Current records
          </button>

          <button
            type="button"
            className={
              recordStatus ===
              "ARCHIVED"
                ? "active"
                : ""
            }
            onClick={() =>
              changeRecordStatus(
                "ARCHIVED",
              )
            }
          >
            Archived records
          </button>
        </nav>
      )}

      {scope && (
        <section className="directory-scope">
          <div>
            <span>
              Directory scope
            </span>

            <strong>
              {formatValue(
                scope.type,
              )}
            </strong>
          </div>

          <div>
            <span>
              Division
            </span>

            <strong>
              {scope.division
                ?.name ??
                "All divisions"}
            </strong>
          </div>

          <div>
            <span>
              Department
            </span>

            <strong>
              {scope.department
                ?.name ??
                "All departments"}
            </strong>
          </div>

          <div>
            <span>
              Contact access
            </span>

            <strong>
              {formatValue(
                scope.contactVisibility,
              )}
            </strong>
          </div>
        </section>
      )}

      <section
        className="directory-toolbar"
        aria-label="Directory search and filters"
      >
        <form
          className="directory-search"
          onSubmit={
            submitSearch
          }
        >
          <label>
            <span>
              Search directory
            </span>

            <div className="directory-search__control">
              <span
                className="directory-search__icon"
                aria-hidden="true"
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                >
                  <circle
                    cx="11"
                    cy="11"
                    r="7"
                  />
                  <path d="m20 20-3.5-3.5" />
                </svg>
              </span>

              <input
                type="search"
                value={
                  searchInput
                }
                onChange={(
                  event,
                ) =>
                  setSearchInput(
                    event.target.value,
                  )
                }
                maxLength={100}
                placeholder="Name, employee ID, designation or department"
              />

              <button
                type="submit"
              >
                Search
              </button>
            </div>
          </label>
        </form>

        <section className="directory-filters">
          <label>
            <span>Role</span>

            <select
              value={role}
              onChange={(
                event,
              ) =>
                changeRole(
                  event.target
                    .value as
                    RoleFilter,
                )
              }
            >
              <option value="">
                All roles
              </option>

              <option value="SUPER_ADMIN">
                Super Admin
              </option>

              <option value="SENIOR_MANAGEMENT">
                Senior Management
              </option>

              <option value="TEAM_MANAGER">
                Team Manager
              </option>

              <option value="EMPLOYEE">
                Employee
              </option>
            </select>
          </label>

          <label>
            <span>
              Employee status
            </span>

            <select
              value={
                employeeStatus
              }
              onChange={(
                event,
              ) =>
                changeEmployeeStatus(
                  event.target
                    .value as
                    EmployeeStatusFilter,
                )
              }
            >
              <option value="">
                All statuses
              </option>

              <option value="ACTIVE">
                Active
              </option>

              <option value="INACTIVE">
                Inactive
              </option>
            </select>
          </label>

          <label>
            <span>
              Employment
            </span>

            <select
              value={
                employmentStatus
              }
              onChange={(
                event,
              ) =>
                changeEmploymentStatus(
                  event.target
                    .value as
                    EmploymentStatusFilter,
                )
              }
            >
              <option value="">
                All employment states
              </option>

              <option value="ACTIVE">
                Active
              </option>

              <option value="RESIGNED">
                Resigned
              </option>

              <option value="RETIRED">
                Retired
              </option>

              <option value="TERMINATED">
                Terminated
              </option>

              <option value="TRANSFERRED">
                Transferred
              </option>
            </select>
          </label>

          <label>
            <span>
              Account status
            </span>

            <select
              value={
                accountStatus
              }
              onChange={(
                event,
              ) =>
                changeAccountStatus(
                  event.target
                    .value as
                    AccountStatusFilter,
                )
              }
            >
              <option value="">
                All accounts
              </option>

              <option value="ENABLED">
                Enabled
              </option>

              <option value="DISABLED">
                Disabled
              </option>

              <option value="NO_ACCOUNT">
                No account
              </option>
            </select>
          </label>

          <label>
            <span>
              Activation
            </span>

            <select
              value={
                activationStatus
              }
              onChange={(
                event,
              ) =>
                changeActivationStatus(
                  event.target
                    .value as
                    ActivationStatusFilter,
                )
              }
            >
              <option value="">
                All activation states
              </option>

              <option value="ACTIVATED">
                Activated
              </option>

              <option value="AWAITING_ACTIVATION">
                Awaiting activation
              </option>
            </select>
          </label>

          <button
            type="button"
            className="directory-clear-button"
            onClick={
              clearFilters
            }
            disabled={
              !hasActiveFilters
            }
          >
            Clear filters
          </button>
        </section>
      </section>

      {error && (
        <div
          className="directory-error"
          role="alert"
        >
          <div>
            <strong>
              Directory unavailable
            </strong>

            <p>{error}</p>
          </div>

          <button
            type="button"
            onClick={
              retryLoading
            }
          >
            Try again
          </button>
        </div>
      )}

      {loading &&
        !response && (
          <div className="directory-loading">
            <div className="spinner" />

            <p>
              Loading employee
              directory...
            </p>
          </div>
        )}

      {!loading &&
        !error &&
        employees.length ===
          0 && (
          <div className="directory-empty">
            <div
              aria-hidden="true"
            >
              NT
            </div>

            <h3>
              {recordStatus ===
              "ARCHIVED"
                ? "No archived employees"
                : "No employees found"}
            </h3>

            <p>
              {recordStatus ===
              "ARCHIVED"
                ? "Archived employee records will appear here."
                : "Change the search or filters and try again."}
            </p>
          </div>
        )}

      {employees.length >
        0 && (
        <>
          <div className="directory-results-bar">
            <div>
              <strong>
                {recordStatus ===
                "ARCHIVED"
                  ? "Archived employees"
                  : "Employees"}
              </strong>

              <span>
                Showing {firstVisibleRecord}–{lastVisibleRecord} of {pagination?.total ?? 0}
              </span>
            </div>

            {loading &&
              response && (
              <span
                className="directory-results-bar__updating"
                role="status"
              >
                Updating results…
              </span>
            )}
          </div>

          <div className="directory-table-wrap">
          <table className="directory-table">
            <caption className="sr-only">
              Authorized Nepal Telecom employee directory
            </caption>

            <thead>
              <tr>
                <th>
                  Employee
                </th>

                <th>
                  Effective role
                </th>

                <th>
                  Current position
                </th>

                <th>
                  Organization
                </th>

                <th>
                  Employment
                </th>

                <th>
                  Account
                </th>

                <th>
                  Activation
                </th>

                <th>
                  {recordStatus ===
                  "ARCHIVED"
                    ? "Archived on"
                    : "Last login"}
                </th>

                <th
                  aria-label="Profile actions"
                />
              </tr>
            </thead>

            <tbody>
              {employees.map(
                (
                  employee,
                ) => (
                  <tr
                    key={
                      employee.id
                    }
                    className={
                      selectedEmployeeId ===
                      employee.id
                        ? "is-selected"
                        : ""
                    }
                  >
                    <td data-label="Employee">
                      <button
                        type="button"
                        className="directory-employee-button"
                        onClick={() =>
                          selectEmployee(
                            employee,
                          )
                        }
                      >
                        {renderDirectoryAvatar(employee)}

                        <span>
                          <strong>
                            {
                              employee.empName
                            }
                          </strong>

                          <small>
                            {
                              employee.empId
                            }
                          </small>

                          <small>
                            {employee.designation ??
                              "No designation"}
                          </small>
                        </span>
                      </button>
                    </td>

                    <td data-label="Effective role">
                      <span
                        className={`directory-badge role-${getStatusClass(
                          employee.effectiveRole ??
                            "NO_ACCOUNT",
                        )}`}
                      >
                        {employee.effectiveRole
                          ? formatValue(
                              employee.effectiveRole,
                            )
                          : "No account"}
                      </span>
                    </td>

                    <td data-label="Current position">
                      <strong>
                        {getCurrentPositionLabel(
                          employee,
                        )}
                      </strong>

                      <small>
                        {employee.currentPosition
                          ? `${formatValue(
                              employee.currentPosition.status,
                            )} position`
                          : "No current assignment"}
                      </small>
                    </td>

                    <td data-label="Organization">
                      <strong>
                        {employee.department
                          ?.name ??
                          "No department"}
                      </strong>

                      <small>
                        {employee.division
                          ?.name ??
                          "No division"}
                      </small>
                    </td>

                    <td data-label="Employment">
                      <span
                        className={`directory-badge ${getStatusClass(
                          employee.employmentStatus,
                        )}`}
                      >
                        {formatValue(
                          employee.employmentStatus,
                        )}
                      </span>
                    </td>

                    <td data-label="Account">
                      <span
                        className={`directory-badge ${getStatusClass(
                          employee.accountStatus,
                        )}`}
                      >
                        {formatValue(
                          employee.accountStatus,
                        )}
                      </span>
                    </td>

                    <td data-label="Activation">
                      <span
                        className={`directory-badge ${getStatusClass(
                          employee.activationStatus,
                        )}`}
                      >
                        {formatValue(
                          employee.activationStatus,
                        )}
                      </span>
                    </td>

                    <td
                      className="directory-date"
                      data-label={
                        recordStatus ===
                        "ARCHIVED"
                          ? "Archived on"
                          : "Last login"
                      }
                    >
                      <strong>
                        {formatDate(
                          recordStatus ===
                          "ARCHIVED"
                            ? employee.archivedAt
                            : employee.lastLoginAt,
                        )}
                      </strong>
                    </td>

                    <td
                      className="directory-row-action"
                      data-label="Profile"
                    >
                      <button
                        type="button"
                        aria-label={`View ${employee.empName} profile`}
                        onClick={() =>
                          selectEmployee(
                            employee,
                          )
                        }
                      >
                        <span>View</span>
                        <span aria-hidden="true">›</span>
                      </button>
                    </td>
                  </tr>
                ),
              )}
            </tbody>
          </table>
          </div>
        </>
      )}

      {pagination &&
        pagination.totalPages >
          1 && (
          <footer className="directory-pagination">
            <button
              type="button"
              onClick={() =>
                changePage(
                  page - 1,
                )
              }
              disabled={
                loading ||
                page <= 1
              }
            >
              Previous
            </button>

            <span>
              Page{" "}
              {pagination.page} of{" "}
              {
                pagination.totalPages
              }
            </span>

            <button
              type="button"
              onClick={() =>
                changePage(
                  page + 1,
                )
              }
              disabled={
                loading ||
                page >=
                  pagination.totalPages
              }
            >
              Next
            </button>
          </footer>
        )}
    </section>
  );
}
